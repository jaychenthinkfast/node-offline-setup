
setInterval(function() {
  console.log(process.env.TOTO);
}, 1000);
